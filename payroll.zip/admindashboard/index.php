<?php include 'includes/header.php'; ?>

<div class="main-panel">
<div class="content-wrapper">
<?php include 'pages/home.php'; ?>
</div>
<?php include 'includes/footer.php'; ?>
