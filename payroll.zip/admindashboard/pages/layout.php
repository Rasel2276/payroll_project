<?php include '../includes/header.php'; ?>

<div class="main-panel">
<div class="content-wrapper">

</div>
<?php include '../includes/footer.php'; ?>