          <!-- partial:partials/_footer.html -->
          <footer class="footer" style="background-color:#191c24;">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2024 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved. Distributed by <a href="https://themewagon.com/">ThemeWagon</a></span>
              <span class="text-muted float-none float-sm-end d-block mt-1 mt-sm-0 text-center"> <span class="text-muted float-none float-sm-end d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span> <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="/payroll/employeedashboard/assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="/payroll/employeedashboard/assets/vendors/chart.js/chart.umd.js"></script>
    <script src="/payroll/employeedashboard/assets/vendors/progressbar.js/progressbar.min.js"></script>
    <script src="/payroll/employeedashboard/assets/vendors/jvectormap/jquery-jvectormap.min.js"></script>
    <script src="/payroll/employeedashboard/assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="/payroll/employeedashboard/assets/vendors/owl-carousel-2/owl.carousel.min.js"></script>
    <script src="/payroll/employeedashboard/assets/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="/payroll/employeedashboard/assets/js/off-canvas.js"></script>
    <script src="/payroll/employeedashboard/assets/js/misc.js"></script>
    <script src="/payroll/employeedashboard/assets/js/settings.js"></script>
    <script src="/payroll/employeedashboard/assets/js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="/payroll/employeedashboard/assets/js/proBanner.js"></script>
    <script src="/payroll/employeedashboard/assets/js/dashboard.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>